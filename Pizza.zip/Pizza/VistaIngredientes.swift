//
//  VistaIngredientes.swift
//  Pizza
//
//  Created by Israel Rodriguez Ibarra on 05/02/16.
//  Copyright © 2016 Israel Rodriguez Ibarra. All rights reserved.
//

import UIKit

class VistaIngredientes: UIViewController {

    var transTamMasQueIng : String = ""
    var transMasQueIng : String = ""
    var transQueIng: String = ""
    
    var activos : Int = 0
    
    var arreglo : [String] = []
    var ingredientes : [String] = []
    
    var flag1 : Bool = false
    var flag2 : Bool = false
    var flag3 : Bool = false
    var flag4 : Bool = false
    var flag5 : Bool = false
    var flag6 : Bool = false
    var flag7 : Bool = false
    var flag8 : Bool = false
    var flag9 : Bool = false
    var flag10 : Bool = false
    
    var ing1: String = ""
    var ing2: String = ""
    var ing3: String = ""
    var ing4: String = ""
    var ing5: String = ""
    var ing6: String = ""
    var ing7: String = ""
    var ing8: String = ""
    var ing9: String = ""
    var ing10: String = ""
    
    var ingrediente1 : String = "-"
    var ingrediente2 : String = "-"
    var ingrediente3 : String = "-"
    var ingrediente4 : String = "-"
    var ingrediente5 : String = "-"
    
    @IBOutlet weak var etiquetaIngredientes: UILabel!
    
    @IBOutlet weak var sw01: UISwitch!
    @IBOutlet weak var sw02: UISwitch!
    @IBOutlet weak var sw03: UISwitch!
    @IBOutlet weak var sw04: UISwitch!
    @IBOutlet weak var sw05: UISwitch!
    @IBOutlet weak var sw06: UISwitch!
    @IBOutlet weak var sw07: UISwitch!
    @IBOutlet weak var sw08: UISwitch!
    @IBOutlet weak var sw09: UISwitch!
    @IBOutlet weak var sw10: UISwitch!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        sw01.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
        sw02.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
        sw03.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
        sw04.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
        sw05.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
        sw06.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
        sw07.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
        sw08.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
        sw09.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
        sw10.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
    }
    
    func Zero() {
        sw01.setOn(false, animated:true)
        sw02.setOn(false, animated:true)
        sw03.setOn(false, animated:true)
        sw04.setOn(false, animated:true)
        sw05.setOn(false, animated:true)
        sw06.setOn(false, animated:true)
        sw07.setOn(false, animated:true)
        sw08.setOn(false, animated:true)
        sw09.setOn(false, animated:true)
        sw10.setOn(false, animated:true)

        arreglo = []; ingredientes = []
        
        activos = 0
        
        flag1 = false; flag2 = false
        flag3 = false; flag4 = false
        flag5 = false; flag6 = false
        flag7 = false; flag8 = false
        flag9 = false; flag10 = false
        
        ing1 = ""; ing2 = ""; ing3 = ""
        ing4 = ""; ing5 = ""; ing6 = ""
        ing7 = ""; ing8 = ""; ing9 = ""
        ing10 = ""
        
        ingrediente1 = "-"; ingrediente2 = "-"
        ingrediente3 = "-"; ingrediente4 = "-"
        ingrediente5 = "-"

    }

    func stateChanged(switchState: UISwitch) {
        if switchState.on {
            ++activos
            switch activos {
            case 1...4:
                etiquetaIngredientes.text = "Escoge " + String(5 - (activos)) + " Ingredientes más"
                print(activos)
                controlActivos()
            case 5:
                etiquetaIngredientes.text = "5 Ingredientes seleccionados"
                alerta()
                print(activos)
                controlActivos()
            default:
                alerta()
                print(activos)
                controlActivos()
            }
            
        } else {
            --activos
            etiquetaIngredientes.text = "Escoge " + String(5 - (activos)) + " Ingredientes más"
            print(activos)
            controlActivos()
        }
    }
    
    func controlActivos() {
        if activos <= 5 {
            if sw01.on && flag1 == false {
                flag1 = true
                ing1 = "Ingrediente 1 activo"
                print(ing1)
                arreglo += ["sw01"]
                print(arreglo)
            } else if !sw01.on && flag1 == true {
                flag1 = false
                ing1 = "Ingrediente 1 desactivado"
                print(ing1)
                let temp = arreglo.removeLast()
                temp
                print(arreglo)
            }
            if sw02.on && flag2 == false {
                flag2 = true
                ing2 = "Ingrediente 2 activo"
                print(ing2)
                arreglo += ["sw02"]
                print(arreglo)
            } else if !sw02.on && flag2 == true {
                flag2 = false
                ing2 = "Ingrediente 2 desactivado"
                print(ing2)
                let temp = arreglo.removeLast()
                temp
                print(arreglo)
            }
            if sw03.on && flag3 == false {
                flag3 = true
                ing3 = "Ingrediente 3 activo"
                print(ing3)
                arreglo += ["sw03"]
                print(arreglo)
            } else if !sw03.on && flag3 == true {
                flag3 = false
                ing3 = "Ingrediente 3 desactivado"
                print(ing3)
                let temp = arreglo.removeLast()
                temp
                print(arreglo)
            }
            if sw04.on && flag4 == false {
                flag4 = true
                ing4 = "Ingrediente 4 activo"
                print(ing4)
                arreglo += ["sw04"]
                print(arreglo)
            } else if !sw04.on && flag4 == true {
                flag4 = false
                ing4 = "Ingrediente 4 desactivado"
                print(ing4)
                let temp = arreglo.removeLast()
                temp
                print(arreglo)
            }
            if sw05.on && flag5 == false {
                flag5 = true
                ing5 = "Ingrediente 5 activo"
                print(ing5)
                arreglo += ["sw05"]
                print(arreglo)
            } else if !sw05.on && flag5 == true {
                flag5 = false
                ing5 = "Ingrediente 5 desactivado"
                print(ing5)
                let temp = arreglo.removeLast()
                temp
                print(arreglo)
            }
            if sw06.on && flag6 == false {
                flag6 = true
                ing6 = "Ingrediente 6 activo"
                print(ing6)
                arreglo += ["sw06"]
                print(arreglo)
            } else if !sw06.on && flag6 == true {
                flag6 = false
                ing6 = "Ingrediente 6 desactivado"
                print(ing6)
                let temp = arreglo.removeLast()
                temp
                print(arreglo)
            }
            if sw07.on && flag7 == false {
                flag7 = true
                ing7 = "Ingrediente 7 activo"
                print(ing7)
                arreglo += ["sw07"]
                print(arreglo)
            } else if !sw07.on && flag7 == true {
                flag7 = false
                ing7 = "Ingrediente 7 desactivado"
                print(ing7)
                let temp = arreglo.removeLast()
                temp
                print(arreglo)
            }
            if sw08.on && flag8 == false {
                flag8 = true
                ing8 = "Ingrediente 8 activo"
                print(ing8)
                arreglo += ["sw08"]
                print(arreglo)
            } else if !sw08.on && flag8 == true {
                flag8 = false
                ing8 = "Ingrediente 8 desactivado"
                print(ing8)
                let temp = arreglo.removeLast()
                temp
                print(arreglo)
            }
            if sw09.on && flag9 == false {
                flag9 = true
                ing9 = "Ingrediente 9 activo"
                print(ing9)
                arreglo += ["sw09"]
                print(arreglo)
            } else if !sw09.on && flag9 == true {
                flag9 = false
                ing9 = "Ingrediente 9 desactivado"
                print(ing9)
                let temp = arreglo.removeLast()
                temp
                print(arreglo)
            }
            if sw10.on && flag10 == false {
                flag10 = true
                ing10 = "Ingrediente 10 activo"
                print(ing10)
                arreglo += ["sw10"]
                print(arreglo)
            } else if !sw10.on && flag10 == true {
                flag10 = false
                ing10 = "Ingrediente 10 desactivado"
                print(ing10)
                let temp = arreglo.removeLast()
                temp
                print(arreglo)
            }
        }
        if activos == 6 {
            --activos
            if sw01.on && flag1 == false {
                sw01.setOn(false, animated:true)
            }
            if sw02.on && flag2 == false {
                sw02.setOn(false, animated:true)
            }
            if sw03.on && flag3 == false {
                sw03.setOn(false, animated:true)
            }
            if sw04.on && flag4 == false {
                sw04.setOn(false, animated:true)
            }
            if sw05.on && flag5 == false {
                sw05.setOn(false, animated:true)
            }
            if sw06.on && flag6 == false {
                sw06.setOn(false, animated:true)
            }
            if sw07.on && flag7 == false {
                sw07.setOn(false, animated:true)
            }
            if sw08.on && flag8 == false {
                sw08.setOn(false, animated:true)
            }
            if sw09.on && flag9 == false {
                sw09.setOn(false, animated:true)
            }
            if sw10.on && flag10 == false {
                sw10.setOn(false, animated:true)
            }
        }
        
    }
    
    func alerta() {
        let alertController = UIAlertController(title: "5 Ingredientes Seleccionados", message: "Confirma tu orden!", preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default,handler: nil))
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    func alertaSinSeleccion() {
        let alertController = UIAlertController(title: "Sin selección", message: "Selecciona al menos un ingrediente!", preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default,handler: nil))
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }

    override func viewDidAppear(animated: Bool) {
        Zero()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func ordenIngredientes() {
        
        var pos : Int = 0
        var cantidad : Int = 0

        arreglo.sortInPlace()
        cantidad = arreglo.count
        print(arreglo)
        
        while pos < cantidad
        {
            if arreglo[pos] == "sw01" {
                ingredientes += ["Jamón"]
            }
            if arreglo[pos] == "sw02" {
                ingredientes += ["Pepperoni"]
            }
            if arreglo[pos] == "sw03" {
                ingredientes += ["Pavo"]
            }
            if arreglo[pos] == "sw04" {
                ingredientes += ["Salchicha"]
            }
            if arreglo[pos] == "sw05" {
                ingredientes += ["Aceituna"]
            }
            if arreglo[pos] == "sw06" {
                ingredientes += ["Cebolla"]
            }
            if arreglo[pos] == "sw07" {
                ingredientes += ["Pimiento"]
            }
            if arreglo[pos] == "sw08" {
                ingredientes += ["Piña"]
            }
            if arreglo[pos] == "sw09" {
                ingredientes += ["Anchoa"]
            }
            if arreglo[pos] == "sw10" {
                ingredientes += ["Champiñones"]
            }
            ++pos
        }
        
        var cont : Int = 0
        cont = ingredientes.count
        
        if cont == 1 {
            ingrediente1 = ingredientes[0]
        }
        if cont == 2 {
            ingrediente1 = ingredientes[0]
            ingrediente2 = ingredientes[1]
        }
        if cont == 3 {
            ingrediente1 = ingredientes[0]
            ingrediente2 = ingredientes[1]
            ingrediente3 = ingredientes[2]
        }
        if cont == 4 {
            ingrediente1 = ingredientes[0]
            ingrediente2 = ingredientes[1]
            ingrediente3 = ingredientes[2]
            ingrediente4 = ingredientes[3]
        }
        if cont == 5 {
            ingrediente1 = ingredientes[0]
            ingrediente2 = ingredientes[1]
            ingrediente3 = ingredientes[2]
            ingrediente4 = ingredientes[3]
            ingrediente5 = ingredientes[4]
        }
        

    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        let sigVista = segue.destinationViewController as! VistaConfirmacion
        
        if activos == 0 {
            alertaSinSeleccion()
        }

        
        ordenIngredientes()
        
        sigVista.transTamMasQueIngCon = transTamMasQueIng
        sigVista.transMasQueIngCon = transMasQueIng
        sigVista.transQueIngCon = transQueIng
        sigVista.transIng1Con = ingrediente1
        sigVista.transIng2Con = ingrediente2
        sigVista.transIng3Con = ingrediente3
        sigVista.transIng4Con = ingrediente4
        sigVista.transIng5Con = ingrediente5
    }

    
    @IBAction func botonIngredientes(sender: AnyObject) {
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
